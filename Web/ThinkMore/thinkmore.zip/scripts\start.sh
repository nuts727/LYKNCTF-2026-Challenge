#!/bin/sh
set -eu

# ─── DNS alias for internal SSRF challenge path ─────────────────────────────
echo "127.0.0.1 cache-proxy" >> /etc/hosts

# ─── Runtime directories ────────────────────────────────────────────────────
mkdir -p /app/storage/cache /app/storage/logs /app/storage/runtime

# ─── Instance seed (shared between web + renderer) ──────────────────────────
seed_file="${INSTANCE_SEED_PATH:-/app/storage/runtime/instance_seed}"
if [ ! -s "$seed_file" ]; then
    python3 -c "import secrets; print(secrets.token_hex(16))" > "$seed_file"
    chmod 0644 "$seed_file"
fi

# ─── Flag handling moved to entrypoint.sh ──────────────────────────────────

# ─── Reset DB (clean state each restart) ─────────────────────────────────────
rm -f /app/storage/app.db

# ─── Start internal renderer (background) ────────────────────────────────────
python3 /app/internal/app.py &

# Wait for renderer to be ready
sleep 2

# ─── Start web server (foreground) ───────────────────────────────────────────
exec php -S 0.0.0.0:2415 -t /app/public /app/public/router.php
