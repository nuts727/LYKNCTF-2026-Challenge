<?php

declare(strict_types=1);

namespace Challenge\Services;

final class InviteTokenService
{
    public function __construct(
        private readonly string $teamSlug,
        private readonly string $inviteKeyPart,
        private readonly string $release,
        private readonly string $instanceSeed
    ) {
    }

    public function verify(string $token): ?array
    {
        $pieces = explode('.', $token, 2);

        if (count($pieces) !== 2) {
            return null;
        }

        [$encodedPayload, $signature] = $pieces;
        $payloadJson = $this->base64UrlDecode($encodedPayload);

        if ($payloadJson === null) {
            return null;
        }

        $payload = json_decode($payloadJson, true);

        if (!is_array($payload)) {
            return null;
        }

        $expectedSignature = hash_hmac('sha256', $this->canonicalJson($payload), $this->secret());

        if (!hash_equals($expectedSignature, $signature)) {
            return null;
        }

        if (($payload['role'] ?? null) !== 'admin') {
            return null;
        }

        if (($payload['scope'] ?? null) !== 'backoffice') {
            return null;
        }

        if (($payload['team'] ?? null) !== $this->teamSlug) {
            return null;
        }

        if (!isset($payload['email']) || !filter_var((string) $payload['email'], FILTER_VALIDATE_EMAIL)) {
            return null;
        }

        if (!isset($payload['exp']) || !is_numeric($payload['exp']) || (int) $payload['exp'] < time()) {
            return null;
        }

        return $payload;
    }

    private function secret(): string
    {
        return hash(
            'sha256',
            $this->inviteKeyPart . ':' . $this->teamSlug . ':' . $this->release . ':' . $this->instanceSeed,
            true
        );
    }

    private function canonicalJson(array $payload): string
    {
        ksort($payload);

        return json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '{}';
    }

    private function base64UrlDecode(string $value): ?string
    {
        $padding = strlen($value) % 4;

        if ($padding > 0) {
            $value .= str_repeat('=', 4 - $padding);
        }

        $decoded = base64_decode(strtr($value, '-_', '+/'), true);

        return $decoded === false ? null : $decoded;
    }
}
