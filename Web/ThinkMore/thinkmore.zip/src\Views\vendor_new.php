<section class="panel">
    <h1>Create Vendor</h1>
    <p class="muted">Submit a vendor record and a logo URL. The portal fetches the remote asset and stores a text preview for review.</p>
    <form action="/mirror" method="post">
        <div class="field">
            <label for="name">Vendor Name</label>
            <input id="name" name="name" type="text" maxlength="80" required>
        </div>
        <div class="field">
            <label for="logo_url">Logo URL</label>
            <input id="logo_url" name="logo_url" type="url" placeholder="http://example.com/logo.txt" required>
        </div>
        <button type="submit">Warm preview cache</button>
    </form>
</section>
