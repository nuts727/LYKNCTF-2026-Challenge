<div class="hero">
    <section class="panel">
        <h1>Hello, <?= e((string) $greeting['text']) ?></h1>
        <p class="muted">Signed in as <?= e((string) $currentUser['email']) ?> with role <strong><?= e((string) $currentUser['role']) ?></strong>.</p>
        <?php if (!empty($greeting['note'])): ?>
            <div class="warning"><?= e((string) $greeting['note']) ?></div>
        <?php endif; ?>
    </section>

    <section class="panel">
        <h2>Quick Actions</h2>
        <p><a href="/profile">Edit profile</a></p>
        <?php if (($currentUser['role'] ?? 'user') === 'admin'): ?>
            <p><a href="/admin">Open billing backoffice</a></p>
        <?php endif; ?>
    </section>
</div>

<section class="panel">
    <h2>Your Vendor Queue</h2>
    <p class="muted">Cached previews are stored as text responses for review. Remote warm-up jobs are delegated to a separate renderer worker.</p>
    <?php if (!$vendors): ?>
        <p>No vendors yet.</p>
    <?php else: ?>
        <table class="table">
            <thead>
            <tr>
                <th>Name</th>
                <th>Status</th>
                <th>Created</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($vendors as $vendor): ?>
                <tr>
                    <td><?= e((string) $vendor['name']) ?></td>
                    <td><?= e((string) $vendor['fetch_status']) ?></td>
                    <td><?= e((string) $vendor['created_at']) ?></td>
                    <td><a href="/vendors/<?= (int) $vendor['id'] ?>">View</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>

