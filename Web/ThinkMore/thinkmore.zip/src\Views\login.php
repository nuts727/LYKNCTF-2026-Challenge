<div class="auth-shell">
    <section class="panel">
        <h1>Login</h1>
        <p class="muted">Sign in to manage vendors and review cached previews.</p>
        <form action="/login" method="post">
            <div class="field">
                <label for="email">Email</label>
                <input id="email" name="email" type="email" required autocomplete="username">
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input id="password" name="password" type="password" required autocomplete="current-password">
            </div>
            <button type="submit">Login</button>
        </form>
    </section>
</div>

