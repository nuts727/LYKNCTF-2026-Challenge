<section class="panel">
    <h1>Not Found</h1>
    <p class="muted">The requested record or route does not exist.</p>
</section>
