<div class="grid">
    <section class="panel">
        <h1>Billing Template</h1>
        <p class="muted">Template changes are stored by the PHP frontend and rendered by the internal invoice worker during preview.</p>
        <p class="muted">Available context fields: <code>customer_name</code>, <code>reviewer_name</code>, <code>amount</code>.</p>
        <form action="/admin/billing/template" method="post" data-template-guard>
            <div class="field">
                <label for="billing_template">Template</label>
                <textarea id="billing_template" name="billing_template" data-template-input><?= e((string) $billingTemplate) ?></textarea>
            </div>
            <button type="submit">Save template</button>
            <div class="warning" data-template-warning hidden></div>
        </form>
    </section>

    <section class="panel">
        <h2>Invoice Preview</h2>
        <p class="muted">Preview always renders the currently saved billing template through the internal renderer service.</p>
        <form action="/admin/billing/preview" method="post">
            <button type="submit" class="secondary">Generate preview</button>
        </form>
        <?php if ($previewError): ?>
            <div class="flash error" style="margin-top: 16px;"><?= e((string) $previewError) ?></div>
        <?php endif; ?>
        <?php if ($previewResult !== null): ?>
            <pre class="code" style="margin-top: 16px;"><?= e((string) $previewResult) ?></pre>
        <?php endif; ?>
    </section>
</div>

