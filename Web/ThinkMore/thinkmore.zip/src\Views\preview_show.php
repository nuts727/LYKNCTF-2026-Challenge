<section class="panel">
    <h1>Cached Preview</h1>
    <div class="meta">
        <span>Status: <?= e((string) $vendor['fetch_status']) ?></span>
        <span>Content-Type: <?= e((string) $vendor['preview_content_type']) ?></span>
    </div>
    <p><strong>Source URL:</strong> <?= e((string) $vendor['logo_url']) ?></p>
    <pre class="code"><?= e((string) $formattedPreviewBody) ?></pre>
</section>

