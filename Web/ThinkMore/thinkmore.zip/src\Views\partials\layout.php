<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e(($pageTitle ?? $appName) . ' - ' . $appName) ?></title>
    <link rel="stylesheet" href="/assets/app.css">
    <script defer src="/assets/app.js"></script>
</head>
<body>
<div class="shell">
    <header class="topbar">
        <a class="brand" href="<?= $currentUser ? '/dashboard' : '/login' ?>"><?= e($appName) ?></a>
        <nav class="nav">
            <?php if ($currentUser): ?>
                <a href="/dashboard">Dashboard</a>
                <a href="/profile">Profile</a>
                <?php if (($currentUser['role'] ?? 'user') === 'admin'): ?>
                    <a href="/admin">Admin</a>
                <?php endif; ?>
                <form action="/logout" method="post" class="inline-form">
                    <button type="submit" class="secondary">Logout</button>
                </form>
            <?php else: ?>
                <a href="/login">Login</a>
                <a href="/register">Register</a>
            <?php endif; ?>
        </nav>
    </header>

    <?php if ($message = consume_flash('error')): ?>
        <div class="flash error"><?= e($message) ?></div>
    <?php endif; ?>

    <?php if ($message = consume_flash('success')): ?>
        <div class="flash success"><?= e($message) ?></div>
    <?php endif; ?>

    <?= $content ?>
</div>
</body>
</html>

