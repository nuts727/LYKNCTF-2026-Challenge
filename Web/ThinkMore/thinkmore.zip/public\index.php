<?php

declare(strict_types=1);

use Challenge\Services\GreetingRenderer;
use Challenge\Services\InternalRendererClient;
use Challenge\Services\InviteTokenService;
use Challenge\Services\MathExpressionEvaluator;
use Challenge\Services\VendorFetcher;

$app = require __DIR__ . '/../src/bootstrap.php';
$config = $app['config'];
$db = $app['db'];

$greetingRenderer = new GreetingRenderer(new MathExpressionEvaluator());
$vendorFetcher = new VendorFetcher();
$inviteTokens = new InviteTokenService(
    $config['team_slug'],
    $config['invite_key_part'],
    $config['release'],
    $config['instance_seed']
);
$rendererClient = new InternalRendererClient($config['internal_renderer_url']);

header('X-Release: ' . $config['release']);
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self'; script-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'");

$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/';
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$currentUser = current_user($db);

if ($path === '/') {
    redirect($currentUser ? '/dashboard' : '/login');
}

if ($path === '/register' && $method === 'GET') {
    if ($currentUser) {
        redirect('/dashboard');
    }

    render('register', [
        'appName' => $config['app_name'],
        'currentUser' => $currentUser,
        'pageTitle' => 'Register',
    ]);
    return;
}

if ($path === '/register' && $method === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('error', 'Please enter a valid email address.');
        redirect('/register');
    }

    if (!preg_match('/^[\x20-\x7E]{2,40}$/', $username)) {
        flash('error', 'Username must be 2-40 printable ASCII characters.');
        redirect('/register');
    }

    if (strlen($password) < 8) {
        flash('error', 'Password must be at least 8 characters long.');
        redirect('/register');
    }

    $exists = $db->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
    $exists->execute([':email' => $email]);

    if ($exists->fetch()) {
        flash('error', 'That email is already registered.');
        redirect('/register');
    }

    $statement = $db->prepare(
        'INSERT INTO users (email, username, password_hash, role, created_at)
         VALUES (:email, :username, :password_hash, :role, :created_at)'
    );
    $statement->execute([
        ':email' => $email,
        ':username' => $username,
        ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
        ':role' => 'user',
        ':created_at' => gmdate('c'),
    ]);

    $_SESSION['user_id'] = (int) $db->lastInsertId();
    session_regenerate_id(true);
    flash('success', 'Account created. Welcome to the vendor portal.');
    redirect('/dashboard');
}

if ($path === '/login' && $method === 'GET') {
    if ($currentUser) {
        redirect('/dashboard');
    }

    render('login', [
        'appName' => $config['app_name'],
        'currentUser' => $currentUser,
        'pageTitle' => 'Login',
    ]);
    return;
}

if ($path === '/login' && $method === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    $statement = $db->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
    $statement->execute([':email' => $email]);
    $user = $statement->fetch();

    if (!$user || !password_verify($password, (string) $user['password_hash'])) {
        flash('error', 'Invalid email or password.');
        redirect('/login');
    }

    $_SESSION['user_id'] = (int) $user['id'];
    session_regenerate_id(true);
    flash('success', 'Welcome back.');
    redirect('/dashboard');
}

if ($path === '/logout' && $method === 'POST') {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $params['path'], $params['domain'] ?? '', (bool) $params['secure'], (bool) $params['httponly']);
    }

    session_destroy();
    redirect('/login');
}

if (!$currentUser) {
    flash('error', 'Please log in first.');
    redirect('/login');
}

if ($path === '/dashboard' && $method === 'GET') {
    $statement = $db->prepare(
        'SELECT id, name, fetch_status, created_at FROM vendors WHERE user_id = :user_id ORDER BY id DESC'
    );
    $statement->execute([':user_id' => (int) $currentUser['id']]);
    $vendors = $statement->fetchAll();

    $greeting = $greetingRenderer->render((string) $currentUser['username']);

    render('dashboard', [
        'appName' => $config['app_name'],
        'currentUser' => $currentUser,
        'pageTitle' => 'Dashboard',
        'vendors' => $vendors,
        'greeting' => $greeting,
    ]);
    return;
}

if ($path === '/profile' && $method === 'GET') {
    render('profile', [
        'appName' => $config['app_name'],
        'currentUser' => $currentUser,
        'pageTitle' => 'Profile',
    ]);
    return;
}

if ($path === '/profile' && $method === 'POST') {
    $username = trim((string) ($_POST['username'] ?? ''));

    if (!preg_match('/^[\x20-\x7E]{2,40}$/', $username)) {
        flash('error', 'Username must be 2-40 printable ASCII characters.');
        redirect('/profile');
    }

    $statement = $db->prepare('UPDATE users SET username = :username WHERE id = :id');
    $statement->execute([
        ':username' => $username,
        ':id' => (int) $currentUser['id'],
    ]);

    flash('success', 'Profile updated.');
    redirect('/dashboard');
}

if ($path === '/mirror' && $method === 'GET') {
    render('vendor_new', [
        'appName' => $config['app_name'],
        'currentUser' => $currentUser,
        'pageTitle' => 'New Vendor',
    ]);
    return;
}

if ($path === '/mirror' && $method === 'POST') {
    $name = trim((string) ($_POST['name'] ?? ''));
    $logoUrl = trim((string) ($_POST['logo_url'] ?? ''));

    if ($name === '' || strlen($name) > 80) {
        flash('error', 'Vendor name must be between 1 and 80 characters.');
        redirect('/mirror');
    }

    if ($logoUrl === '') {
        flash('error', 'Please provide a logo URL.');
        redirect('/mirror');
    }

    $result = $vendorFetcher->fetch($logoUrl);

    $statement = $db->prepare(
        'INSERT INTO vendors (user_id, name, logo_url, fetch_status, preview_content_type, preview_body, created_at)
         VALUES (:user_id, :name, :logo_url, :fetch_status, :preview_content_type, :preview_body, :created_at)'
    );
    $statement->execute([
        ':user_id' => (int) $currentUser['id'],
        ':name' => $name,
        ':logo_url' => $logoUrl,
        ':fetch_status' => $result['fetch_status'],
        ':preview_content_type' => $result['preview_content_type'],
        ':preview_body' => $result['preview_body'],
        ':created_at' => gmdate('c'),
    ]);

    flash('success', 'Vendor queued for preview warming.');
    redirect('/previews/' . $db->lastInsertId());
}

if ($method === 'GET' && preg_match('#^/vendors/(\d+)$#', $path, $matches)) {
    $vendor = find_vendor_for_user($db, (int) $matches[1], $currentUser);

    if (!$vendor) {
        http_response_code(404);
        render('not_found', [
            'appName' => $config['app_name'],
            'currentUser' => $currentUser,
            'pageTitle' => 'Not Found',
        ]);
        return;
    }

    render('vendor_show', [
        'appName' => $config['app_name'],
        'currentUser' => $currentUser,
        'pageTitle' => 'Vendor',
        'vendor' => $vendor,
    ]);
    return;
}

if ($method === 'GET' && preg_match('#^/previews/(\d+)$#', $path, $matches)) {
    $vendor = find_vendor_for_user($db, (int) $matches[1], $currentUser);

    if (!$vendor) {
        http_response_code(404);
        render('not_found', [
            'appName' => $config['app_name'],
            'currentUser' => $currentUser,
            'pageTitle' => 'Not Found',
        ]);
        return;
    }

    render('preview_show', [
        'appName' => $config['app_name'],
        'currentUser' => $currentUser,
        'pageTitle' => 'Preview Cache',
        'vendor' => $vendor,
        'formattedPreviewBody' => format_preview_body((string) $vendor['preview_body']),
    ]);
    return;
}

if ($path === '/invite/accept' && $method === 'POST') {
    $token = trim((string) ($_POST['token'] ?? ''));
    $payload = $inviteTokens->verify($token);

    if (!$payload) {
        flash('error', 'Invite token was rejected.');
        redirect('/dashboard');
    }

    if (strcasecmp((string) $payload['email'], (string) $currentUser['email']) !== 0) {
        flash('error', 'Invite token email does not match the active session.');
        redirect('/dashboard');
    }

    $statement = $db->prepare('UPDATE users SET role = :role WHERE id = :id');
    $statement->execute([
        ':role' => 'admin',
        ':id' => (int) $currentUser['id'],
    ]);

    flash('success', 'Backoffice access granted.');
    redirect('/admin');
}

if (($path === '/admin' || $path === '/admin/billing') && $method === 'GET') {
    if (($currentUser['role'] ?? 'user') !== 'admin') {
        flash('error', 'Backoffice access is restricted.');
        redirect('/dashboard');
    }

    render('admin', [
        'appName' => $config['app_name'],
        'currentUser' => $currentUser,
        'pageTitle' => 'Admin Billing',
        'billingTemplate' => setting($db, 'billing_template'),
        'previewResult' => null,
        'previewError' => null,
    ]);
    return;
}

if ($path === '/admin/billing/template' && $method === 'POST') {
    if (($currentUser['role'] ?? 'user') !== 'admin') {
        flash('error', 'Backoffice access is restricted.');
        redirect('/dashboard');
    }

    $template = (string) ($_POST['billing_template'] ?? '');

    if ($template === '' || strlen($template) > 4_000) {
        flash('error', 'Billing template must be between 1 and 4000 characters.');
        redirect('/admin');
    }

    save_setting($db, 'billing_template', $template);
    flash('success', 'Billing template saved.');
    redirect('/admin');
}

if ($path === '/admin/billing/preview' && $method === 'POST') {
    if (($currentUser['role'] ?? 'user') !== 'admin') {
        flash('error', 'Backoffice access is restricted.');
        redirect('/dashboard');
    }

    $template = setting($db, 'billing_template');
    $result = $rendererClient->renderInvoice($template, [
        'customer_name' => 'Cedar Supplies',
        'reviewer_name' => (string) $currentUser['username'],
        'amount' => '1480',
    ]);

    render('admin', [
        'appName' => $config['app_name'],
        'currentUser' => $currentUser,
        'pageTitle' => 'Admin Billing',
        'billingTemplate' => $template,
        'previewResult' => $result['ok'] ? (string) $result['rendered'] : null,
        'previewError' => $result['ok'] ? null : (string) $result['error'],
    ]);
    return;
}

http_response_code(404);
render('not_found', [
    'appName' => $config['app_name'],
    'currentUser' => $currentUser,
    'pageTitle' => 'Not Found',
]);
