<div class="auth-shell">
    <section class="panel">
        <h1>Register</h1>
        <p class="muted">Create a basic reviewer account to start submitting vendor records.</p>
        <form action="/register" method="post">
            <div class="field">
                <label for="username">Username</label>
                <input id="username" name="username" type="text" required maxlength="40">
            </div>
            <div class="field">
                <label for="email">Email</label>
                <input id="email" name="email" type="email" required autocomplete="username">
            </div>
            <div class="field">
                <label for="password">Password</label>
                <input id="password" name="password" type="password" required minlength="8" autocomplete="new-password">
            </div>
            <button type="submit">Create account</button>
        </form>
    </section>
</div>

