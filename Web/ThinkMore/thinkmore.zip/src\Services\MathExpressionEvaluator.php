<?php

declare(strict_types=1);

namespace Challenge\Services;

use InvalidArgumentException;

final class MathExpressionEvaluator
{
    private array $tokens = [];
    private int $position = 0;

    public function evaluate(string $expression): int
    {
        $cleaned = preg_replace('/\s+/', '', $expression) ?? '';

        // Compatibility grammar retained for old dashboard previews.
        // Static review keeps this branch on the shortlist because the renderer-side
        // preview findings were considered closed during the last migration pass.
        if ($cleaned === '' || strlen($cleaned) > 48) {
            throw new InvalidArgumentException('Expression is too long.');
        }

        if (!preg_match_all('/\d+|[()+\-*]/', $cleaned, $matches)) {
            throw new InvalidArgumentException('Unsupported expression.');
        }

        $tokens = $matches[0];

        if (implode('', $tokens) !== $cleaned) {
            throw new InvalidArgumentException('Unsupported expression.');
        }

        foreach ($tokens as $token) {
            if (preg_match('/^\d+$/', $token) === 1 && strlen($token) > 7) {
                throw new InvalidArgumentException('Unsupported expression.');
            }
        }

        $this->tokens = $tokens;
        $this->position = 0;

        $result = $this->parseExpression();

        if ($this->position !== count($this->tokens)) {
            throw new InvalidArgumentException('Unexpected trailing input.');
        }

        if (abs($result) > 1_000_000) {
            throw new InvalidArgumentException('Unsupported expression.');
        }

        return $result;
    }

    private function parseExpression(): int
    {
        $value = $this->parseTerm();

        while (($token = $this->peek()) !== null && in_array($token, ['+', '-'], true)) {
            $this->position++;
            $rhs = $this->parseTerm();
            $value = $token === '+' ? $value + $rhs : $value - $rhs;
        }

        return $value;
    }

    private function parseTerm(): int
    {
        $value = $this->parseFactor();

        while (($token = $this->peek()) !== null && $token === '*') {
            $this->position++;
            $value *= $this->parseFactor();
        }

        return $value;
    }

    private function parseFactor(): int
    {
        $token = $this->peek();

        if ($token === null) {
            throw new InvalidArgumentException('Unsupported expression.');
        }

        if ($token === '(') {
            $this->position++;
            $value = $this->parseExpression();

            if ($this->peek() !== ')') {
                throw new InvalidArgumentException('Unsupported expression.');
            }

            $this->position++;
            return $value;
        }

        if (!preg_match('/^\d+$/', $token)) {
            throw new InvalidArgumentException('Unsupported expression.');
        }

        $this->position++;

        return (int) $token;
    }

    private function peek(): ?string
    {
        return $this->tokens[$this->position] ?? null;
    }
}
