<section class="panel">
    <h1>Profile</h1>
    <p class="muted">Your username is rendered on the dashboard greeting widget.</p>
    <form action="/profile" method="post">
        <div class="field">
            <label for="username">Username</label>
            <input id="username" name="username" type="text" maxlength="40" value="<?= e((string) $currentUser['username']) ?>" required>
        </div>
        <div class="field">
            <label>Email</label>
            <input type="text" value="<?= e((string) $currentUser['email']) ?>" disabled>
        </div>
        <button type="submit">Save profile</button>
    </form>
</section>

