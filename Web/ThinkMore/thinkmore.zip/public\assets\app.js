// TODO: move cache-proxy to CDN before GA
document.addEventListener('DOMContentLoaded', () => {
  const guardedForm = document.querySelector('[data-template-guard]');
  const templateInput = document.querySelector('[data-template-input]');
  const warning = document.querySelector('[data-template-warning]');

  if (guardedForm && templateInput && warning) {
    guardedForm.addEventListener('submit', (event) => {
      const value = templateInput.value;
      if (value.includes('{{') || value.includes('{%') || value.includes('}}') || value.includes('%}')) {
        event.preventDefault();
        warning.hidden = false;
        warning.textContent = 'The browser editor blocked protected placeholder syntax.';
      }
    });
  }
});
