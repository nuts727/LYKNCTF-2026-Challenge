<?php

declare(strict_types=1);

function env_value(string $key, ?string $default = null): ?string
{
    $value = getenv($key);

    return $value === false ? $default : $value;
}

function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): never
{
    header('Location: ' . $path);
    exit;
}

function flash(string $key, ?string $message = null): ?string
{
    if (!isset($_SESSION['_flash'])) {
        $_SESSION['_flash'] = [];
    }

    if ($message !== null) {
        $_SESSION['_flash'][$key] = $message;
        return null;
    }

    return $_SESSION['_flash'][$key] ?? null;
}

function consume_flash(string $key): ?string
{
    if (!isset($_SESSION['_flash'][$key])) {
        return null;
    }

    $value = $_SESSION['_flash'][$key];
    unset($_SESSION['_flash'][$key]);

    return $value;
}

function initialize_database(PDO $db): void
{
    $db->exec(
        <<<'SQL'
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            username TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS vendors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            logo_url TEXT NOT NULL,
            fetch_status TEXT NOT NULL,
            preview_content_type TEXT NOT NULL,
            preview_body TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS settings (
            setting_key TEXT PRIMARY KEY,
            setting_value TEXT NOT NULL
        );
        SQL
    );

    $defaultTemplate = <<<'TPL'
<h1>Invoice for Cedar Supplies</h1>
<p>Prepared by Review Desk</p>
<p>Total due: $1480</p>
TPL;

    $statement = $db->prepare(
        'INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES (:key, :value)'
    );
    $statement->execute([
        ':key' => 'billing_template',
        ':value' => $defaultTemplate,
    ]);
}

function current_user(PDO $db): ?array
{
    if (!isset($_SESSION['user_id'])) {
        return null;
    }

    static $cache = null;

    if ($cache !== null && (int) $cache['id'] === (int) $_SESSION['user_id']) {
        return $cache;
    }

    $statement = $db->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
    $statement->execute([':id' => (int) $_SESSION['user_id']]);
    $user = $statement->fetch();

    $cache = $user ?: null;

    return $cache;
}

function find_vendor_for_user(PDO $db, int $vendorId, array $user): ?array
{
    $sql = 'SELECT * FROM vendors WHERE id = :id';
    $params = [':id' => $vendorId];

    if (($user['role'] ?? 'user') !== 'admin') {
        $sql .= ' AND user_id = :user_id';
        $params[':user_id'] = (int) $user['id'];
    }

    $sql .= ' LIMIT 1';

    $statement = $db->prepare($sql);
    $statement->execute($params);
    $vendor = $statement->fetch();

    return $vendor ?: null;
}

function render(string $view, array $params = []): void
{
    $viewFile = __DIR__ . '/../Views/' . $view . '.php';
    $layoutFile = __DIR__ . '/../Views/partials/layout.php';

    if (!is_file($viewFile)) {
        throw new RuntimeException('View not found: ' . $view);
    }

    extract($params, EXTR_SKIP);

    ob_start();
    require $viewFile;
    $content = ob_get_clean();

    require $layoutFile;
}

function setting(PDO $db, string $key, string $default = ''): string
{
    $statement = $db->prepare('SELECT setting_value FROM settings WHERE setting_key = :key LIMIT 1');
    $statement->execute([':key' => $key]);
    $value = $statement->fetchColumn();

    return $value === false ? $default : (string) $value;
}

function save_setting(PDO $db, string $key, string $value): void
{
    $statement = $db->prepare(
        'INSERT INTO settings (setting_key, setting_value) VALUES (:key, :value)
         ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value'
    );
    $statement->execute([
        ':key' => $key,
        ':value' => $value,
    ]);
}

function format_preview_body(string $body): string
{
    if ($body === '') {
        return '(empty response body)';
    }

    if (preg_match('//u', $body) !== 1) {
        return 'HEX:' . strtoupper(bin2hex(substr($body, 0, 512)));
    }

    return $body;
}
