<?php

declare(strict_types=1);

namespace Challenge\Services;

final class InternalRendererClient
{
    public function __construct(private readonly string $baseUrl)
    {
    }

    public function renderInvoice(string $template, array $context): array
    {
        $payload = json_encode([
            'template' => $template,
            'context' => $context,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if ($payload === false) {
            return [
                'ok' => false,
                'error' => 'Failed to encode invoice payload.',
            ];
        }

        $handle = curl_init(rtrim($this->baseUrl, '/') . '/render/invoice');
        curl_setopt_array($handle, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Content-Length: ' . strlen($payload),
            ],
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 5,
        ]);

        $response = curl_exec($handle);

        if ($response === false) {
            $error = curl_error($handle);
            curl_close($handle);

            return [
                'ok' => false,
                'error' => 'Renderer request failed: ' . $error,
            ];
        }

        $httpCode = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        curl_close($handle);

        $data = json_decode($response, true);

        if ($httpCode !== 200) {
            return [
                'ok' => false,
                'error' => $data['error'] ?? 'Renderer rejected the request.',
            ];
        }

        return [
            'ok' => true,
            'rendered' => (string) ($data['rendered'] ?? ''),
        ];
    }
}
