# Think More

**Category:** Web  
**Difficulty:** Medium  
**Flag format:** `LYKNCTF{...}`  
**Port:** 2415

## Description

Vendor Review Portal — một hệ thống quản lý vendor và preview logo nội bộ của team alpha.

Bạn vừa tìm được portal này trên internet. Nghe đồn có một hệ thống billing nội bộ ẩn chứa thông tin nhạy cảm. Liệu bạn có thể truy cập vào backoffice và khai thác nó?

> *"Sometimes the mirror reflects more than you think."*

## Setup

```bash
docker build -t think-more .
docker run -d -p 2415:2415 think-more
```

Challenge sẽ chạy tại `http://localhost:2415`

## Hints

<details>
<summary>Hint 1 (Free)</summary>
Trang vendor cho phép bạn "mirror" nội dung từ URL bên ngoài. Liệu nó có kiểm tra kỹ URL đích?
</details>

<details>
<summary>Hint 2 (-50 điểm)</summary>
Có một internal service ẩn sau frontend. Tìm cách giao tiếp với nó qua một alias khác.
</details>

<details>
<summary>Hint 3 (-100 điểm)</summary>
Source map đôi khi chứa nhiều thông tin hơn bạn nghĩ. Tìm cách lấy build-info của renderer.
</details>
