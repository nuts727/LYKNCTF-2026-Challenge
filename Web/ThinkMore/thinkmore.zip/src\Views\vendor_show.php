<section class="panel">
    <h1><?= e((string) $vendor['name']) ?></h1>
    <div class="meta">
        <span>Status: <?= e((string) $vendor['fetch_status']) ?></span>
        <span>Content-Type: <?= e((string) $vendor['preview_content_type']) ?></span>
        <span>Created: <?= e((string) $vendor['created_at']) ?></span>
    </div>
    <p><strong>Logo URL:</strong> <?= e((string) $vendor['logo_url']) ?></p>
    <p><a class="button secondary" href="/previews/<?= (int) $vendor['id'] ?>">Open cached preview</a></p>
</section>

