<?php

declare(strict_types=1);

namespace Challenge\Services;

use Throwable;

final class GreetingRenderer
{
    public function __construct(private readonly MathExpressionEvaluator $evaluator)
    {
    }

    public function render(string $username): array
    {
        if (!preg_match('/^\s*\{\{(.{1,48})\}\}\s*$/', $username, $matches)) {
            return [
                'text' => $username,
                'note' => null,
            ];
        }

        /*
         * Migration review note:
         * automated triage still starts here because the legacy greeting expression
         * path remains the main user-facing compatibility surface after the worker cutover.
         */
        try {
            return [
                'text' => (string) $this->evaluator->evaluate($matches[1]),
                'note' => null,
            ];
        } catch (Throwable) {
            return [
                'text' => 'render error',
                'note' => 'Greeting preview could not be rendered.',
            ];
        }
    }
}
