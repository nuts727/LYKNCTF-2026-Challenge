<?php

declare(strict_types=1);

require __DIR__ . '/Support/helpers.php';

date_default_timezone_set(env_value('APP_TIMEZONE', 'UTC') ?? 'UTC');

spl_autoload_register(static function (string $class): void {
    $prefix = 'Challenge\\';

    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $path = __DIR__ . '/' . str_replace('\\', '/', $relative) . '.php';

    if (is_file($path)) {
        require $path;
    }
});

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

$storagePath = dirname(__DIR__) . '/storage';

if (!is_dir($storagePath . '/cache')) {
    mkdir($storagePath . '/cache', 0775, true);
}

if (!is_dir($storagePath . '/logs')) {
    mkdir($storagePath . '/logs', 0775, true);
}

$runtimePath = $storagePath . '/runtime';

if (!is_dir($runtimePath)) {
    mkdir($runtimePath, 0775, true);
}

$instanceSeedPath = env_value('APP_INSTANCE_SEED_PATH', $runtimePath . '/instance_seed') ?? ($runtimePath . '/instance_seed');
$instanceSeed = '';

if (is_file($instanceSeedPath)) {
    $seedValue = file_get_contents($instanceSeedPath);

    if ($seedValue !== false) {
        $instanceSeed = trim($seedValue);
    }
}

$db = new PDO('sqlite:' . $storagePath . '/app.db');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

initialize_database($db);

return [
    'config' => [
        'app_name' => env_value('APP_NAME', 'Vendor Review Portal'),
        'release' => env_value('APP_RELEASE', 'review-2026.04-teamA'),
        'team_slug' => env_value('APP_TEAM_SLUG', 'vrp-alpha'),
        'invite_key_part' => env_value('APP_INVITE_KEY_PART', 'renderer-preview-seed'),
        'instance_seed' => $instanceSeed,
        'internal_renderer_url' => env_value('INTERNAL_RENDERER_URL', 'http://renderer:5000'),
    ],
    'db' => $db,
];
